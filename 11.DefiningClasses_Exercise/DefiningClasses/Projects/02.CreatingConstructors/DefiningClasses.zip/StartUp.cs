﻿using System;
using System.Net.Http.Headers;

namespace DefiningClasses
{
    public class StartUp
    {
        public static void Main(string[] args)
        {

            Person person1 = new Person();                     // Тук ще сетне: No name, 1
            Person person2 = new Person(12);                   // Тук ще сетне: No name, 12
            Person person3 = new Person("Stoyan", 24);         // Тук ще сетне: Stoyan, 24
        }
    }
}
